const hre = require("hardhat");

async function main() {
    const [attacker, victim] = await hre.ethers.getSigners();
    console.log("[+] QR Code Attack initiated");

    const deployments = require("../deployments.json");
    const qr = await hre.ethers.getContractAt("QRCodeAttack", deployments.QRCodeAttack);

    const trapId = hre.ethers.utils.keccak256(hre.ethers.utils.toUtf8Bytes("USDT_TRAP_1"));
    const fakeAddr = "0x1234567890123456789012345678901234567890";

    await qr.createQRTrap(
        trapId,
        "USDT Official Deposit",
        fakeAddr,
        attacker.address,
        hre.ethers.utils.parseUnits("1000", 6)
    );

    const trap = await qr.getTrap(trapId);
    console.log("[i] QR Trap created:");
    console.log("    Label:", trap.label);
    console.log("    Fake Address:", trap.fakeAddress);
    console.log("    Real Target:", trap.realTarget);

    await qr.recordQRDeposit(trapId, {value: hre.ethers.utils.parseEther("0.5")});
    console.log("[✓] Victim funds redirected via QR trap");

    await qr.batchUSDTTraps(5);
    console.log("[✓] Batch USDT traps generated");
}

main().catch(console.error);
