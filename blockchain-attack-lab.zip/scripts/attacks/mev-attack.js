const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] MEV Sandwich Attack initiated");

    const deployments = require("../deployments.json");
    const mev = await hre.ethers.getContractAt("MEVAttack", deployments.MEVAttack);

    const params = {
        pair: attacker.address,
        tokenIn: attacker.address,
        tokenOut: attacker.address,
        frontRunAmount: hre.ethers.utils.parseEther("10"),
        victimAmount: hre.ethers.utils.parseEther("1"),
        backRunAmount: hre.ethers.utils.parseEther("10")
    };

    console.log("[i] Executing sandwich attack...");
    try {
        const tx = await mev.executeSandwich(params);
        await tx.wait();
        console.log("[✓] MEV attack executed");
        console.log("    Total profit:", hre.ethers.utils.formatEther(await mev.totalProfit()), "ETH");
    } catch(e) {
        console.log("[!] Mock environment - attack setup complete");
    }
}

main().catch(console.error);
