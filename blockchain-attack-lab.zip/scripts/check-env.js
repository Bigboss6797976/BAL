const fs = require('fs');
const path = require('path');

function check() {
    console.log("========================================");
    console.log("  BAL Environment Check");
    console.log("========================================");

    const checks = {
        node: false,
        npm: false,
        hardhat: false,
        dotenv: false,
        contracts: false
    };

    try {
        const nodeVersion = process.version;
        checks.node = true;
        console.log(`[✓] Node.js: ${nodeVersion}`);
    } catch(e) {
        console.log("[✗] Node.js not found");
    }

    try {
        require('hardhat');
        checks.hardhat = true;
        console.log("[✓] Hardhat installed");
    } catch(e) {
        console.log("[✗] Hardhat not installed. Run: npm install");
    }

    const envPath = path.join(__dirname, '..', '.env');
    if (fs.existsSync(envPath)) {
        checks.dotenv = true;
        console.log("[✓] .env file exists");
    } else {
        console.log("[✗] .env missing. Run: node auto-config.js");
    }

    const contractsDir = path.join(__dirname, '..', 'contracts');
    if (fs.existsSync(contractsDir)) {
        const files = fs.readdirSync(contractsDir);
        checks.contracts = files.length > 0;
        console.log(`[✓] Contracts: ${files.length} files found`);
    }

    const allOk = Object.values(checks).every(v => v);
    console.log("========================================");
    console.log(allOk ? "[✓] All checks passed!" : "[!] Some checks failed");
}

check();
