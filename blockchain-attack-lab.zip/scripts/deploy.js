const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
    const [deployer] = await hre.ethers.getSigners();
    console.log("Deploying with:", deployer.address);

    const deployments = {};

    // 1. 重入攻击套件
    const ReentrancyVulnerable = await hre.ethers.getContractFactory("ReentrancyVulnerable");
    const vuln = await ReentrancyVulnerable.deploy();
    await vuln.deployed();
    deployments.ReentrancyVulnerable = vuln.address;
    console.log("[1/16] ReentrancyVulnerable:", deployments.ReentrancyVulnerable);

    // 2. 重入攻击者
    const ReentrancyAttacker = await hre.ethers.getContractFactory("ReentrancyAttacker");
    const attacker = await ReentrancyAttacker.deploy(deployments.ReentrancyVulnerable);
    await attacker.deployed();
    deployments.ReentrancyAttacker = attacker.address;
    console.log("[2/16] ReentrancyAttacker:", deployments.ReentrancyAttacker);

    // 3. 闪电贷攻击
    const FlashLoanAttack = await hre.ethers.getContractFactory("FlashLoanAttack");
    const flash = await FlashLoanAttack.deploy(deployer.address, deployer.address);
    await flash.deployed();
    deployments.FlashLoanAttack = flash.address;
    console.log("[3/16] FlashLoanAttack:", deployments.FlashLoanAttack);

    // 4. Gas攻击
    const GasAttack = await hre.ethers.getContractFactory("GasAttack");
    const gas = await GasAttack.deploy();
    await gas.deployed();
    deployments.GasAttack = gas.address;
    console.log("[4/16] GasAttack:", deployments.GasAttack);

    // 5. MEV攻击
    const MEVAttack = await hre.ethers.getContractFactory("MEVAttack");
    const mev = await MEVAttack.deploy();
    await mev.deployed();
    deployments.MEVAttack = mev.address;
    console.log("[5/16] MEVAttack:", deployments.MEVAttack);

    // 6. 授权陷阱
    const ApproveTrap = await hre.ethers.getContractFactory("ApproveTrap");
    const trap = await ApproveTrap.deploy("FakeAirdrop", "FAKE");
    await trap.deployed();
    deployments.ApproveTrap = trap.address;
    console.log("[6/16] ApproveTrap:", deployments.ApproveTrap);

    // 7. 直接盗窃
    const DirectSteal = await hre.ethers.getContractFactory("DirectSteal");
    const steal = await DirectSteal.deploy();
    await steal.deployed();
    deployments.DirectSteal = steal.address;
    console.log("[7/16] DirectSteal:", deployments.DirectSteal);

    // 8. 盲签攻击
    const BlindSignAttack = await hre.ethers.getContractFactory("BlindSignAttack");
    const blind = await BlindSignAttack.deploy();
    await blind.deployed();
    deployments.BlindSignAttack = blind.address;
    console.log("[8/16] BlindSignAttack:", deployments.BlindSignAttack);

    // 9. QR攻击
    const QRCodeAttack = await hre.ethers.getContractFactory("QRCodeAttack");
    const qr = await QRCodeAttack.deploy();
    await qr.deployed();
    deployments.QRCodeAttack = qr.address;
    console.log("[9/16] QRCodeAttack:", deployments.QRCodeAttack);

    // 10. 后门代币
    const BlacklistBackdoorToken = await hre.ethers.getContractFactory("BlacklistBackdoorToken");
    const blacklist = await BlacklistBackdoorToken.deploy("SafeToken", "SAFE", hre.ethers.utils.parseEther("1000000"));
    await blacklist.deployed();
    deployments.BlacklistBackdoorToken = blacklist.address;
    console.log("[10/16] BlacklistBackdoorToken:", deployments.BlacklistBackdoorToken);

    const ForceTransferToken = await hre.ethers.getContractFactory("ForceTransferToken");
    const force = await ForceTransferToken.deploy("ForceToken", "FORCE", hre.ethers.utils.parseEther("1000000"));
    await force.deployed();
    deployments.ForceTransferToken = force.address;
    console.log("[11/16] ForceTransferToken:", deployments.ForceTransferToken);

    const MintBackdoorToken = await hre.ethers.getContractFactory("MintBackdoorToken");
    const mint = await MintBackdoorToken.deploy("MintToken", "MINT", hre.ethers.utils.parseEther("1000000"), hre.ethers.utils.parseEther("10000000"));
    await mint.deployed();
    deployments.MintBackdoorToken = mint.address;
    console.log("[12/16] MintBackdoorToken:", deployments.MintBackdoorToken);

    // 11. 访问控制
    const AccessControlAttack = await hre.ethers.getContractFactory("AccessControlAttack");
    const access = await AccessControlAttack.deploy();
    await access.deployed();
    deployments.AccessControlAttack = access.address;
    console.log("[13/16] AccessControlAttack:", deployments.AccessControlAttack);

    // 12. 随机数攻击
    const RandomnessAttack = await hre.ethers.getContractFactory("RandomnessAttack");
    const random = await RandomnessAttack.deploy();
    await random.deployed();
    deployments.RandomnessAttack = random.address;
    console.log("[14/16] RandomnessAttack:", deployments.RandomnessAttack);

    // 13. 委托攻击
    const VulnerableDelegate = await hre.ethers.getContractFactory("VulnerableDelegate");
    const delegate = await VulnerableDelegate.deploy();
    await delegate.deployed();
    deployments.VulnerableDelegate = delegate.address;
    console.log("[15/16] VulnerableDelegate:", deployments.VulnerableDelegate);

    // 14. 全链攻击
    const FullChainAttack = await hre.ethers.getContractFactory("FullChainAttack");
    const full = await FullChainAttack.deploy();
    await full.deployed();
    deployments.FullChainAttack = full.address;
    console.log("[16/16] FullChainAttack:", deployments.FullChainAttack);

    // 15. 其他
    const BatchAttack = await hre.ethers.getContractFactory("BatchAttack");
    const batch = await BatchAttack.deploy();
    await batch.deployed();
    deployments.BatchAttack = batch.address;

    const SelfDestructAttack = await hre.ethers.getContractFactory("SelfDestructAttack");
    const selfdest = await SelfDestructAttack.deploy();
    await selfdest.deployed();
    deployments.SelfDestructAttack = selfdest.address;

    const TimestampAttack = await hre.ethers.getContractFactory("TimestampAttack");
    const timestamp = await TimestampAttack.deploy();
    await timestamp.deployed();
    deployments.TimestampAttack = timestamp.address;

    // 保存部署地址
    const deployPath = path.join(__dirname, "..", "deployments.json");
    fs.writeFileSync(deployPath, JSON.stringify(deployments, null, 2));
    console.log("\n[✓] Deployments saved to deployments.json");

    // 生成前端ABI文件
    await generateABIs();
}

async function generateABIs() {
    const artifactsDir = path.join(__dirname, "..", "artifacts", "contracts");
    const abiDir = path.join(__dirname, "..", "frontend", "js");

    if (!fs.existsSync(abiDir)) fs.mkdirSync(abiDir, { recursive: true });

    const contracts = [
        "ReentrancyVulnerable", "ReentrancyAttacker", "FlashLoanAttack",
        "GasAttack", "MEVAttack", "ApproveTrap", "DirectSteal",
        "BlindSignAttack", "QRCodeAttack", "BlacklistBackdoorToken",
        "ForceTransferToken", "MintBackdoorToken", "AccessControlAttack",
        "RandomnessAttack", "VulnerableDelegate", "FullChainAttack",
        "BatchAttack", "SelfDestructAttack", "TimestampAttack",
        "DelegateAttack", "MaliciousImplementation", "LegitImplementation",
        "Proxy"
    ];

    let abiContent = "const BAL_ABIS = {\n";

    for (const name of contracts) {
        const artifactPath = path.join(artifactsDir, `${name}.sol`, `${name}.json`);
        if (fs.existsSync(artifactPath)) {
            const artifact = JSON.parse(fs.readFileSync(artifactPath));
            abiContent += `  ${name}: ${JSON.stringify(artifact.abi)},\n`;
        }
    }

    abiContent += "};\n\nif (typeof module !== 'undefined') module.exports = BAL_ABIS;";
    fs.writeFileSync(path.join(abiDir, "abis.js"), abiContent);
    console.log("[✓] ABIs generated for frontend");
}

main().catch(console.error);
