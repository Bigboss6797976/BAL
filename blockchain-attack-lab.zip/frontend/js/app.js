/**
 * App Entry - 初始化与全局状态
 */
const BAL_VERSION = '2.0.0';

window.addEventListener('load', () => {
    console.log(`%c💀 Blockchain Attack Lab v${BAL_VERSION}`, 
        'color: #ff3333; font-size: 20px; font-weight: bold;');
    console.log('%c⚠️ 仅用于安全研究与教育目的', 'color: #ffaa00;');

    log('Application loaded. Connect wallet to begin.', 'info');
});

// Handle account changes
if (typeof window.ethereum !== 'undefined') {
    window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length === 0) {
            updateStatus('🔴 未连接');
            log('Wallet disconnected', 'warn');
        } else {
            connectWallet();
        }
    });

    window.ethereum.on('chainChanged', () => {
        window.location.reload();
    });
}
