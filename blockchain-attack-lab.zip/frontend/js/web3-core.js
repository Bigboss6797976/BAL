/**
 * Web3 Core - 钱包连接与基础交互
 */
let provider = null;
let signer = null;
let contracts = {};
let deployments = {};

async function connectWallet() {
    if (typeof window.ethereum !== 'undefined') {
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            provider = new ethers.BrowserProvider(window.ethereum);
            signer = await provider.getSigner();

            const network = await provider.getNetwork();
            const block = await provider.getBlockNumber();
            const address = await signer.getAddress();

            updateStatus('🟢 已连接: ' + address.slice(0, 6) + '...' + address.slice(-4));
            document.getElementById('network-info').textContent = 'Network: ' + network.name + ' (' + network.chainId + ')';
            document.getElementById('block-number').textContent = 'Block: ' + block;

            log('Wallet connected: ' + address, 'info');
            loadDeployments();
            return true;
        } catch (e) {
            log('Connection failed: ' + e.message, 'error');
            return false;
        }
    } else {
        log('MetaMask not found! Using read-only mode.', 'warn');
        // Fallback to JSON-RPC
        provider = new ethers.JsonRpcProvider('http://127.0.0.1:8545');
        updateStatus('🟡 只读模式 (localhost:8545)');
        loadDeployments();
        return false;
    }
}

function updateStatus(text) {
    document.getElementById('connection-status').textContent = text;
}

async function loadDeployments() {
    try {
        const res = await fetch('/api/deployments');
        if (res.ok) {
            deployments = await res.json();
            updateContractList();
            log('Deployments loaded: ' + Object.keys(deployments).length + ' contracts', 'info');
        }
    } catch(e) {
        log('Failed to load deployments', 'warn');
    }
}

function updateContractList() {
    const list = document.getElementById('contract-list');
    if (!list) return;
    list.innerHTML = '';
    for (const [name, addr] of Object.entries(deployments)) {
        list.innerHTML += `<div class="contract-item">
            <span class="name">${name}</span><br>
            <span class="addr">${addr}</span>
        </div>`;
    }
}

function getContract(name, address) {
    if (!provider) throw new Error('Not connected');
    const abi = BAL_ABIS[name];
    if (!abi) throw new Error('ABI not found for ' + name);

    if (signer) {
        return new ethers.Contract(address, abi, signer);
    }
    return new ethers.Contract(address, abi, provider);
}

function log(msg, type='info') {
    const consoleEl = document.getElementById('console-log');
    if (!consoleEl) return;
    const time = new Date().toLocaleTimeString();
    const cls = type === 'error' ? 'error' : type === 'warn' ? 'warn' : 'info';
    consoleEl.innerHTML += `<div class="${cls}">[${time}] ${msg}</div>`;
    consoleEl.scrollTop = consoleEl.scrollHeight;
}

// Auto-connect on load
window.addEventListener('load', () => {
    setTimeout(connectWallet, 500);
});
