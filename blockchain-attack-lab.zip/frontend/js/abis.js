const BAL_ABIS = {};

if (typeof module !== 'undefined') module.exports = BAL_ABIS;
