/**
 * UI Bindings - 标签切换与事件绑定
 */
document.addEventListener('DOMContentLoaded', () => {
    // Tab switching
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));

            tab.classList.add('active');
            const target = document.getElementById(tab.dataset.tab);
            if (target) target.classList.add('active');
        });
    });

    // Auto-fill deployment addresses
    setTimeout(() => {
        if (Object.keys(deployments).length > 0) {
            document.getElementById('reentrancy-vuln-addr').value = deployments.ReentrancyVulnerable || '';
            document.getElementById('reentrancy-att-addr').value = deployments.ReentrancyAttacker || '';
            document.getElementById('flash-lender').value = deployments.FlashLoanAttack || '';
            document.getElementById('trap-addr').value = deployments.ApproveTrap || '';
            document.getElementById('blacklist-addr').value = deployments.BlacklistBackdoorToken || '';
            document.getElementById('force-addr').value = deployments.ForceTransferToken || '';
            document.getElementById('mint-addr').value = deployments.MintBackdoorToken || '';
            document.getElementById('access-target').value = deployments.AccessControlAttack || '';
            document.getElementById('random-addr').value = deployments.RandomnessAttack || '';
            document.getElementById('delegate-vuln').value = deployments.VulnerableDelegate || '';
            document.getElementById('timestamp-addr').value = deployments.TimestampAttack || '';
            document.getElementById('fullchain-addr').value = deployments.FullChainAttack || '';
        }
    }, 2000);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'c') {
            document.getElementById('console-log').innerHTML = '';
        }
    });
});
