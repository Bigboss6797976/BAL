# QUICK_REF.md - 快速参考

## 命令速查

| 命令 | 说明 |
|------|------|
| `npm install` | 安装依赖 |
| `npx hardhat compile` | 编译合约 |
| `npx hardhat test` | 运行测试 |
| `npx hardhat node` | 启动本地节点 |
| `npm run deploy` | 部署合约 |
| `npm run server` | 启动前端 |
| `npm run attack:all` | 执行所有攻击 |

## 攻击脚本速查

| 攻击 | 命令 |
|------|------|
| 重入 | `npm run attack:reentrancy` |
| 闪电贷 | `npm run attack:flashloan` |
| MEV | `npm run attack:mev` |
| Gas | `npm run attack:gas` |
| 钓鱼 | `npm run attack:phishing` |
| 后门 | `npm run attack:backdoor` |
| 盲签 | `npm run attack:blind` |
| QR | `npm run attack:qr` |
| 访问控制 | `npm run attack:access` |
| 随机数 | `npm run attack:random` |
| 委托调用 | `npm run attack:delegate` |
| 自毁 | `npm run attack:selfdestruct` |
| 存储碰撞 | `npm run attack:storage` |
| 时间戳 | `npm run attack:time` |
| 批量 | `npm run attack:batch` |
| 全链 | `npm run attack:fullchain` |

## 网络配置

| 网络 | URL | Chain ID |
|------|-----|----------|
| Hardhat | 内置 | 31337 |
| Localhost | http://127.0.0.1:8545 | 31337 |
| Termux | http://127.0.0.1:8545 | 31337 |

## 默认账户

Hardhat默认提供10个测试账户，每个有10,000 ETH。

## 文件位置

| 文件 | 路径 |
|------|------|
| 部署地址 | `deployments.json` |
| 环境配置 | `.env` |
| 编译产物 | `artifacts/contracts/` |
| 前端 | `frontend/` |
| 攻击脚本 | `scripts/attacks/` |
