# ATTACK_VECTORS.md - 攻击向量详解

## 1. 重入攻击 (Reentrancy)

**原理**: 合约在外部调用后才更新状态，攻击者通过递归调用重复提取资金。

**漏洞代码**:
```solidity
function withdraw() external {
    uint256 bal = balances[msg.sender];
    (bool success, ) = msg.sender.call{value: bal}("");  // 外部调用
    balances[msg.sender] = 0;  // 状态更新太晚
}
```

**防御**: Checks-Effects-Interactions 模式，使用重入锁。

## 2. 闪电贷攻击 (Flash Loan)

**原理**: 借入巨额资金操纵DEX价格，套利后归还。

**步骤**:
1. 借入 10,000 ETH
2. 在DEX大量卖出Token A，压低价格
3. 用Token B低价买入大量Token A
4. 归还闪电贷 + 手续费
5. 保留套利利润

## 3. MEV三明治攻击

**原理**: 监控mempool，在受害者交易前后插入交易获利。

**流程**:
```
[攻击者买入] -> [受害者买入(高价)] -> [攻击者卖出(更高价)]
```

## 4. Gas攻击

**类型**:
- Gas Bomb: 大量SSTORE消耗Gas
- Block Fill: 消耗接近区块Gas上限
- Target Gas Exhaustion: 针对特定合约的Gas限制

## 5. 钓鱼攻击

**授权陷阱**: 诱导用户approve恶意合约，然后transferFrom窃取。

**QR钓鱼**: 生成虚假USDT充值二维码，资金实际流向攻击者。

## 6. 后门代币

**黑名单**: Owner可将任意地址加入黑名单并没收资金。

**强制转账**: Owner无需授权即可转移任何用户余额。

**无限铸造**: Owner可无限增发，稀释持有者价值。

## 7. 盲签攻击

**诱导签名**: 构造看似无害的哈希诱导用户签名。

**签名重放**: 在实现不佳的合约中重复使用同一签名。

## 8. 访问控制绕过

**所有权抢夺**: 利用transferOwnership没有权限检查。

**tx.origin钓鱼**: 利用tx.origin而非msg.sender进行权限验证。

**delegatecall注入**: 通过delegatecall执行恶意代码覆写存储。

## 9. 随机数操纵

**blockhash预测**: 使用区块哈希作为随机数源可被预测。

**timestamp操纵**: 矿工可操纵timestamp ±15秒。

## 10. 存储碰撞

**代理合约**: 实现合约与代理合约存储布局不一致导致碰撞。

## 11. 自毁攻击

**强制转账**: 通过selfdestruct向合约强制发送ETH，绕过receive检查。

## 12. 时间戳操纵

**时间锁绕过**: 利用矿工对timestamp的控制权提前释放锁定资金。

## 13. 批量攻击

**批量执行**: 一次交易执行多个攻击调用，降低被检测概率。
