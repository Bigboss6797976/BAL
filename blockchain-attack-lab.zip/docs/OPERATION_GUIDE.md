# OPERATION_GUIDE.md - 操作指南

## 前端操作

### 连接钱包
1. 点击 "🔗 连接钱包"
2. 选择MetaMask或其他Web3钱包
3. 确认网络为本地Hardhat网络 (Chain ID: 31337)

### 部署合约
1. 点击 "🚀 部署全部合约"
2. 等待部署完成
3. 地址自动填充到各攻击模块

### 执行攻击

#### 重入攻击
1. 进入 "🔄 重入攻击" 标签
2. 确认漏洞合约地址
3. 点击 "💰 存入 ETH" 向漏洞合约充值
4. 点击 "⚔️ 执行重入攻击"
5. 查看窃取金额和重入次数
6. 点击 "💎 提取战利品"

#### 闪电贷攻击
1. 进入 "⚡ 闪电贷" 标签
2. 输入闪电贷提供商和DEX地址
3. 设置借款金额和代币地址
4. 点击 "⚡ 执行闪电贷攻击"

#### MEV三明治
1. 进入 "🥪 MEV" 标签
2. 输入交易对和代币地址
3. 设置前置/后置交易金额
4. 点击 "🥪 执行三明治攻击"

#### Gas攻击
1. 进入 "⛽ Gas攻击" 标签
2. 设置炸弹大小
3. 点击 "💣 部署炸弹" 然后 "🔥 引爆炸弹"
4. 或使用 "🧱 填充区块"

#### 钓鱼攻击
1. 进入 "🎣 钓鱼" 标签
2. 输入陷阱合约和受害者地址
3. 点击 "🔍 检查授权"
4. 点击 "🎣 窃取代币"

#### 后门代币
1. 进入 "🚪 后门" 标签
2. 选择后门类型（黑名单/强制转账/无限铸造）
3. 输入目标地址和金额
4. 执行攻击

#### 全链攻击
1. 进入 "🔗 全链攻击" 标签
2. 确认各目标合约地址
3. 点击 "☠️ 执行全链攻击"
4. 查看多步骤攻击结果

## 脚本操作

### 单个攻击
```bash
npm run attack:reentrancy
npm run attack:flashloan
npm run attack:mev
npm run attack:gas
npm run attack:phishing
npm run attack:backdoor
npm run attack:blind
npm run attack:qr
npm run attack:access
npm run attack:random
npm run attack:delegate
npm run attack:selfdestruct
npm run attack:storage
npm run attack:time
npm run attack:batch
npm run attack:fullchain
```

### 批量测试
```bash
npm run test
npm run attack:all  # 运行所有攻击脚本
```

## API操作

### 部署
```bash
curl -X POST http://localhost:3000/api/deploy
```

### 执行攻击
```bash
curl -X POST http://localhost:3000/api/attack/reentrancy
curl -X POST http://localhost:3000/api/attack/gas
```

### 全链攻击
```bash
curl -X POST http://localhost:3000/api/attack-all
```

## 日志查看

前端实时日志位于仪表盘底部，显示所有交易和事件。

## 故障排除

### 交易失败
- 检查Gas限制
- 确认合约地址正确
- 确保账户有足够ETH

### 前端不显示数据
- 刷新页面
- 重新连接钱包
- 检查浏览器控制台错误

### 合约交互失败
- 确认ABI已正确生成
- 检查网络连接
- 验证合约是否已部署
