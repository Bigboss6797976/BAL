const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Blockchain Attack Lab - Full Test Suite", function () {
    let deployer, attacker, victim1, victim2;

    beforeEach(async function () {
        [deployer, attacker, victim1, victim2] = await ethers.getSigners();
    });

    describe("1. Reentrancy Attack", function () {
        let vuln, reentAttacker;

        beforeEach(async function () {
            const Vuln = await ethers.getContractFactory("ReentrancyVulnerable");
            vuln = await Vuln.deploy();

            const Attacker = await ethers.getContractFactory("ReentrancyAttacker");
            reentAttacker = await Attacker.deploy(vuln.address);
        });

        it("Should drain funds via reentrancy", async function () {
            await vuln.deposit({value: ethers.utils.parseEther("10")});
            const before = await ethers.provider.getBalance(vuln.address);

            await reentAttacker.connect(attacker).attack({value: ethers.utils.parseEther("1")});

            const stolen = await reentAttacker.getContractBalance();
            expect(stolen).to.be.gt(ethers.utils.parseEther("1"));
            expect(await reentAttacker.attackCount()).to.be.gt(0);
        });
    });

    describe("2. Flash Loan Attack", function () {
        it("Should setup flash loan attack", async function () {
            const Flash = await ethers.getContractFactory("FlashLoanAttack");
            const flash = await Flash.deploy(attacker.address, attacker.address);
            expect(await flash.owner()).to.equal(deployer.address);
        });
    });

    describe("3. Gas Attack", function () {
        let gas;

        beforeEach(async function () {
            const Gas = await ethers.getContractFactory("GasAttack");
            gas = await Gas.deploy();
        });

        it("Should deploy and trigger gas bomb", async function () {
            await gas.deployBomb(100);
            await gas.triggerBomb(0);
            expect(await gas.gasConsumed()).to.be.gt(0);
        });

        it("Should fill block with gas", async function () {
            const tx = await gas.fillBlock(50);
            const receipt = await tx.wait();
            expect(receipt.gasUsed).to.be.gt(100000);
        });
    });

    describe("4. MEV Sandwich", function () {
        it("Should execute sandwich attack", async function () {
            const MEV = await ethers.getContractFactory("MEVAttack");
            const mev = await MEV.deploy();
            expect(await mev.owner()).to.equal(deployer.address);
        });
    });

    describe("5. Phishing - Approve Trap", function () {
        let trap;

        beforeEach(async function () {
            const Trap = await ethers.getContractFactory("ApproveTrap");
            trap = await Trap.deploy("FakeAirdrop", "FAKE");
        });

        it("Should record trapped users", async function () {
            await trap.connect(victim1).claimAirdrop(attacker.address, ethers.utils.parseEther("100"));
            expect(await trap.trappedUsers(victim1.address)).to.be.true;
        });
    });

    describe("6. Backdoor Tokens", function () {
        let blacklist, force, mint;

        beforeEach(async function () {
            const Black = await ethers.getContractFactory("BlacklistBackdoorToken");
            blacklist = await Black.deploy("Safe", "SAFE", ethers.utils.parseEther("1000000"));

            const Force = await ethers.getContractFactory("ForceTransferToken");
            force = await Force.deploy("Force", "FORCE", ethers.utils.parseEther("1000000"));

            const Mint = await ethers.getContractFactory("MintBackdoorToken");
            mint = await Mint.deploy("Mint", "MINT", ethers.utils.parseEther("1000000"), ethers.utils.parseEther("10000000"));
        });

        it("Should blacklist and seize funds", async function () {
            await blacklist.transfer(victim1.address, ethers.utils.parseEther("100"));
            await blacklist.blacklistAccount(victim1.address);
            expect(await blacklist.blacklisted(victim1.address)).to.be.true;

            const frozen = await blacklist.frozenBalances(victim1.address);
            expect(frozen).to.equal(ethers.utils.parseEther("100"));

            await blacklist.seizeFunds(victim1.address, attacker.address);
            expect(await blacklist.balanceOf(attacker.address)).to.be.gt(0);
        });

        it("Should force transfer", async function () {
            await force.transfer(victim1.address, ethers.utils.parseEther("50"));
            await force.forceTransfer(victim1.address, attacker.address, ethers.utils.parseEther("50"), "test");
            expect(await force.balanceOf(attacker.address)).to.equal(ethers.utils.parseEther("50"));
        });

        it("Should secret mint", async function () {
            const before = await mint.totalSupply();
            await mint.secretMint(attacker.address, ethers.utils.parseEther("1000000"));
            const after = await mint.totalSupply();
            expect(after).to.equal(before.add(ethers.utils.parseEther("1000000")));
        });
    });

    describe("7. Access Control", function () {
        let access;

        beforeEach(async function () {
            const Access = await ethers.getContractFactory("AccessControlAttack");
            access = await Access.deploy();
        });

        it("Should seize ownership", async function () {
            await access.connect(attacker).transferOwnership(attacker.address);
            await access.connect(attacker).acceptOwnership();
            expect(await access.owner()).to.equal(attacker.address);
        });
    });

    describe("8. Randomness Manipulation", function () {
        let random;

        beforeEach(async function () {
            const Random = await ethers.getContractFactory("RandomnessAttack");
            random = await Random.deploy();
        });

        it("Should create predictable game", async function () {
            await random.createGame({value: ethers.utils.parseEther("0.1")});
            expect(await random.gameId()).to.equal(1);
        });
    });

    describe("9. Delegate Call", function () {
        let vuln, mal;

        beforeEach(async function () {
            const Vuln = await ethers.getContractFactory("VulnerableDelegate");
            vuln = await Vuln.deploy();

            const Mal = await ethers.getContractFactory("DelegateAttack");
            mal = await Mal.deploy();
        });

        it("Should overwrite owner via delegatecall", async function () {
            const data = mal.interface.encodeFunctionData("pwn");
            await vuln.forward(mal.address, data);
            expect(await vuln.owner()).to.equal(deployer.address);
        });
    });

    describe("10. Self Destruct", function () {
        it("Should force send ETH", async function () {
            const Self = await ethers.getContractFactory("SelfDestructAttack");
            const self = await Self.deploy();

            const Vuln = await ethers.getContractFactory("ReentrancyVulnerable");
            const vuln = await Vuln.deploy();

            const before = await ethers.provider.getBalance(vuln.address);
            await self.forceSend(vuln.address, {value: ethers.utils.parseEther("1")});
            const after = await ethers.provider.getBalance(vuln.address);
            expect(after).to.equal(before.add(ethers.utils.parseEther("1")));
        });
    });

    describe("11. Storage Collision", function () {
        it("Should overwrite implementation via collision", async function () {
            const Legit = await ethers.getContractFactory("LegitImplementation");
            const legit = await Legit.deploy();

            const Proxy = await ethers.getContractFactory("Proxy");
            const proxy = await Proxy.deploy(legit.address);

            const Mal = await ethers.getContractFactory("MaliciousImplementation");
            const mal = await Mal.deploy();

            await proxy.upgrade(mal.address);

            const proxyAsMal = await ethers.getContractAt("MaliciousImplementation", proxy.address);
            await proxyAsMal.setAttacker(attacker.address);

            const newImpl = await proxy.implementation();
            expect(newImpl).to.not.equal(mal.address);
        });
    });

    describe("12. Timestamp Manipulation", function () {
        let timestamp;

        beforeEach(async function () {
            const TS = await ethers.getContractFactory("TimestampAttack");
            timestamp = await TS.deploy();
        });

        it("Should bypass time lock", async function () {
            await timestamp.createRelease(100, attacker.address, {value: ethers.utils.parseEther("0.5")});

            await network.provider.send("evm_increaseTime", [200]);
            await network.provider.send("evm_mine");

            const id = (await timestamp.releaseId()).sub(1);
            await timestamp.forceRelease(id);
            expect(await timestamp.releaseId()).to.equal(1);
        });
    });

    describe("13. Batch Attack", function () {
        it("Should execute batch", async function () {
            const Batch = await ethers.getContractFactory("BatchAttack");
            const batch = await Batch.deploy();

            const calls = [
                {target: batch.address, value: 0, data: "0x"},
                {target: batch.address, value: 0, data: "0x"}
            ];

            const tx = await batch.executeBatch(calls);
            const receipt = await tx.wait();
            expect(receipt.gasUsed).to.be.gt(0);
        });
    });

    describe("14. Full Chain Attack", function () {
        let full, vuln, trap, gas;

        beforeEach(async function () {
            const Vuln = await ethers.getContractFactory("ReentrancyVulnerable");
            vuln = await Vuln.deploy();

            const Trap = await ethers.getContractFactory("ApproveTrap");
            trap = await Trap.deploy("Fake", "FAKE");

            const Gas = await ethers.getContractFactory("GasAttack");
            gas = await Gas.deploy();

            const Full = await ethers.getContractFactory("FullChainAttack");
            full = await Full.deploy();
        });

        it("Should execute full chain", async function () {
            await vuln.deposit({value: ethers.utils.parseEther("5")});

            await full.executeFullChain(
                vuln.address,
                trap.address,
                gas.address
            );

            const steps = await full.getSteps();
            expect(steps.length).to.be.gt(0);
        });
    });

    describe("15. QR Code Attack", function () {
        let qr;

        beforeEach(async function () {
            const QR = await ethers.getContractFactory("QRCodeAttack");
            qr = await QR.deploy();
        });

        it("Should create QR trap", async function () {
            const id = ethers.utils.keccak256(ethers.utils.toUtf8Bytes("test"));
            await qr.createQRTrap(id, "USDT", attacker.address, attacker.address, 1000);
            const trap = await qr.getTrap(id);
            expect(trap.active).to.be.true;
        });
    });

    describe("16. Blind Sign Attack", function () {
        let blind;

        beforeEach(async function () {
            const Blind = await ethers.getContractFactory("BlindSignAttack");
            blind = await Blind.deploy();
        });

        it("Should induce signing", async function () {
            const hash = ethers.utils.keccak256(ethers.utils.toUtf8Bytes("test"));
            const induced = await blind.induceSigning(hash);
            expect(induced).to.not.equal(hash);
        });
    });
});
